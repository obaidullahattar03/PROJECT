package com.wbl.api_automation.helper;

public interface Constants {
	String PATH=System.getProperty("user.dir")+"\\resources\\";
}
