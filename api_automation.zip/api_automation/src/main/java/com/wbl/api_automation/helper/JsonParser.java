/*package com.wbl.api_automation.helper;

public class JsonParser {
	
	RestResponse response;
	
	public JsonParser(RestResponse response){
		this.response=response;
	}
	

}
*/